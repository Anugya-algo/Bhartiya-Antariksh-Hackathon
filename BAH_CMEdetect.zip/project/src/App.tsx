import React from 'react';
import { Header } from './components/Header';
import { StatusCard } from './components/StatusCard';
import { MetricCard } from './components/MetricCard';
import { EventCard } from './components/EventCard';
import { TimeSeriesChart } from './components/TimeSeriesChart';
import { 
  Brain, 
  Eye, 
  Target, 
  AlertTriangle, 
  Activity, 
  Clock 
} from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <Header />
      
      <div className="p-6">
        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatusCard
            icon={Brain}
            title="DeepHalo"
            value="TSS: 0.907"
            subtitle="Last Prediction: 0.890"
            status="active"
          />
          <StatusCard
            icon={Eye}
            title="CNN Detection"
            value="3 Events"
            subtitle="Processing: 12.4ms"
            status="processing"
          />
          <StatusCard
            icon={Target}
            title="CACTus"
            value="Active"
            subtitle="Autonomous Detection"
            status="active"
          />
          <StatusCard
            icon={AlertTriangle}
            title="Alerts"
            value="1 High Risk"
            subtitle="Geoeffective Events"
            status="warning"
          />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="xl:col-span-2">
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <Activity className="w-6 h-6 text-blue-400" />
                  <h2 className="text-white text-xl font-bold">Solar Magnetic Field Data</h2>
                </div>
                <div className="flex items-center space-x-2 text-slate-400 text-sm">
                  <Clock className="w-4 h-4" />
                  <span>SHARP Parameters • 12min cadence</span>
                </div>
              </div>

              {/* Metric Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <MetricCard
                  title="TOTUSJH"
                  value="103.4"
                  subtitle="Total Unsigned Current Helicity"
                />
                <MetricCard
                  title="TOTBSQ"
                  value="1185.8"
                  subtitle="Total Magnetic Field Energy"
                />
                <MetricCard
                  title="USFLUX"
                  value="589.8"
                  subtitle="Unsigned Magnetic Flux"
                />
              </div>

              <TimeSeriesChart />
            </div>
          </div>

          {/* Events Sidebar */}
          <div className="xl:col-span-1">
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-lg p-6">
              <div className="flex items-center space-x-3 mb-6">
                <Clock className="w-6 h-6 text-orange-400" />
                <h2 className="text-white text-xl font-bold">Active Events</h2>
              </div>

              <div className="space-y-4">
                <EventCard
                  status="detected"
                  timestamp="11:04:04 PM"
                  probability={98.7}
                  velocity={983}
                  width={156}
                  angle={235}
                  riskLevel="LOW"
                />
                <EventCard
                  status="predicted"
                  timestamp="11:04:46 PM"
                  probability={62.9}
                  velocity={1294}
                  width={123}
                  angle={17}
                  riskLevel="LOW"
                />
                <EventCard
                  status="detected"
                  timestamp="11:05:01 PM"
                  probability={79.0}
                  velocity={787}
                  width={189}
                  angle={142}
                  riskLevel="HIGH"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;