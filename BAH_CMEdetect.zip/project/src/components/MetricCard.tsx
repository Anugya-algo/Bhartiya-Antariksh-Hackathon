import React from 'react';

interface MetricCardProps {
  title: string;
  value: string;
  subtitle: string;
  color?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  color = 'blue'
}) => {
  return (
    <div className="bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 rounded-lg p-6 hover:bg-slate-800/50 transition-all duration-300">
      <h4 className="text-slate-400 text-sm font-medium mb-2">{title}</h4>
      <p className="text-white text-3xl font-bold mb-1">{value}</p>
      <p className="text-slate-500 text-xs">{subtitle}</p>
    </div>
  );
};