import React, { useState, useEffect } from 'react';
import { Zap } from 'lucide-react';

export const Header: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      month: 'numeric',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700/50 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-br from-purple-500 to-blue-600 p-2 rounded-lg">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-white text-xl font-bold">Halo CME Detection System</h1>
            <p className="text-slate-400 text-sm">Integrated DeepHalo & CNN Analysis Platform</p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-white text-lg font-mono">
            {formatTime(currentTime)} PM
          </div>
          <div className="text-slate-400 text-sm">
            {formatDate(currentTime)}
          </div>
        </div>
      </div>
    </div>
  );
};