import React from 'react';

export const TimeSeriesChart: React.FC = () => {
  // Mock data points for the time series
  const dataPoints = [
    { x: 0, y: 45 },
    { x: 50, y: 35 },
    { x: 100, y: 55 },
    { x: 150, y: 40 },
    { x: 200, y: 60 },
    { x: 250, y: 45 },
    { x: 300, y: 50 },
    { x: 350, y: 65 },
    { x: 400, y: 40 },
    { x: 450, y: 55 },
    { x: 500, y: 35 },
    { x: 550, y: 45 },
    { x: 600, y: 50 },
    { x: 650, y: 60 },
    { x: 700, y: 45 },
    { x: 750, y: 40 },
    { x: 800, y: 55 }
  ];

  const pathData = dataPoints.map((point, index) => 
    `${index === 0 ? 'M' : 'L'} ${point.x} ${120 - point.y}`
  ).join(' ');

  return (
    <div className="bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 rounded-lg p-6 mt-6">
      <h3 className="text-slate-300 text-sm font-medium mb-4">24-Hour Time Series</h3>
      <div className="w-full h-32 relative">
        <svg viewBox="0 0 800 120" className="w-full h-full">
          <defs>
            <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
            </linearGradient>
          </defs>
          
          {/* Grid lines */}
          <g stroke="#374151" strokeWidth="0.5" opacity="0.3">
            {[0, 1, 2, 3, 4].map(i => (
              <line key={i} x1="0" y1={i * 30} x2="800" y2={i * 30} />
            ))}
          </g>
          
          {/* Area under the curve */}
          <path
            d={`${pathData} L 800 120 L 0 120 Z`}
            fill="url(#chartGradient)"
          />
          
          {/* Main line */}
          <path
            d={pathData}
            fill="none"
            stroke="#3b82f6"
            strokeWidth="2"
            className="drop-shadow-sm"
          />
          
          {/* Data points */}
          {dataPoints.map((point, index) => (
            <circle
              key={index}
              cx={point.x}
              cy={120 - point.y}
              r="3"
              fill="#3b82f6"
              className="drop-shadow-sm"
            />
          ))}
        </svg>
      </div>
    </div>
  );
};