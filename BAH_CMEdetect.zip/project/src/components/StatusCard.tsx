import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface StatusCardProps {
  icon: LucideIcon;
  title: string;
  value: string;
  subtitle: string;
  status?: 'active' | 'processing' | 'warning' | 'error';
  color?: string;
}

export const StatusCard: React.FC<StatusCardProps> = ({
  icon: Icon,
  title,
  value,
  subtitle,
  status = 'active',
  color = 'blue'
}) => {
  const statusColors = {
    active: 'border-green-500/30 bg-green-500/5',
    processing: 'border-blue-500/30 bg-blue-500/5',
    warning: 'border-yellow-500/30 bg-yellow-500/5',
    error: 'border-red-500/30 bg-red-500/5'
  };

  const iconColors = {
    active: 'text-green-400',
    processing: 'text-blue-400',
    warning: 'text-yellow-400',
    error: 'text-red-400'
  };

  return (
    <div className={`bg-slate-800/50 backdrop-blur-sm border ${statusColors[status]} rounded-lg p-6 hover:bg-slate-800/70 transition-all duration-300`}>
      <div className="flex items-center justify-between mb-4">
        <Icon className={`w-6 h-6 ${iconColors[status]}`} />
        <div className={`w-2 h-2 rounded-full ${status === 'active' ? 'bg-green-400' : status === 'processing' ? 'bg-blue-400' : status === 'warning' ? 'bg-yellow-400' : 'bg-red-400'} animate-pulse`} />
      </div>
      <h3 className="text-slate-300 text-sm font-medium mb-2">{title}</h3>
      <p className="text-white text-2xl font-bold mb-1">{value}</p>
      <p className="text-slate-400 text-xs">{subtitle}</p>
    </div>
  );
};