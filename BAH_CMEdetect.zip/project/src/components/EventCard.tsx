import React from 'react';
import { Clock, TrendingUp, Compass, Zap } from 'lucide-react';

interface EventCardProps {
  status: 'detected' | 'predicted';
  timestamp: string;
  probability: number;
  velocity: number;
  width: number;
  angle: number;
  riskLevel: 'LOW' | 'HIGH';
}

export const EventCard: React.FC<EventCardProps> = ({
  status,
  timestamp,
  probability,
  velocity,
  width,
  angle,
  riskLevel
}) => {
  const statusColors = {
    detected: 'border-l-purple-500',
    predicted: 'border-l-blue-500'
  };

  const riskColors = {
    LOW: 'bg-green-500/20 text-green-400 border-green-500/30',
    HIGH: 'bg-red-500/20 text-red-400 border-red-500/30'
  };

  return (
    <div className={`bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 ${statusColors[status]} border-l-4 rounded-lg p-4 hover:bg-slate-800/50 transition-all duration-300 mb-4`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${status === 'detected' ? 'bg-purple-500' : 'bg-blue-500'} animate-pulse`} />
          <span className="text-white font-medium capitalize">{status}</span>
        </div>
        <span className={`px-2 py-1 text-xs font-medium rounded border ${riskColors[riskLevel]}`}>
          {riskLevel}
        </span>
      </div>
      
      <div className="flex items-center space-x-2 mb-3">
        <Clock className="w-4 h-4 text-slate-400" />
        <span className="text-slate-300 text-sm">{timestamp}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 text-sm">
        <div>
          <p className="text-slate-400">Probability</p>
          <p className="text-white font-medium">{probability}%</p>
        </div>
        <div>
          <p className="text-slate-400">Velocity</p>
          <p className="text-white font-medium">{velocity} km/s</p>
        </div>
        <div>
          <p className="text-slate-400">Width</p>
          <p className="text-white font-medium">{width}°</p>
        </div>
        <div>
          <p className="text-slate-400">Angle</p>
          <p className="text-white font-medium">{angle}°</p>
        </div>
      </div>
    </div>
  );
};